

<?php $__env->startSection('title'); ?>
Нарушений нет | Заявления
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>



<div class="card">
    <div class="card-body">
        <h5 class="card-title">Заказ №<?php echo e($order->id); ?></h5>
        <p class="card-text text-truncate"><?php echo e($order->address); ?></p>
        <p>Статус: <?php echo e($order->status); ?></p>
        <h3>Корзина</h3>
        <p>

            <?php $__currentLoopData = $productsCounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productCount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $productsNames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($productName); ?>:<?php echo e($productCount); ?> <br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </p>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\foodkor\resources\views/orders/show.blade.php ENDPATH**/ ?>