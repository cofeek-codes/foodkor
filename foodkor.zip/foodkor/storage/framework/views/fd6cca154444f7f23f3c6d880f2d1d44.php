<?php $__env->startSection('title'); ?>
Нарушений нет | Создать продукт
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="my-auto">
    <form action="/products/create" method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="title" class="form-label">Название</label>
            <input type="text" name="name" class="form-control" id="title" aria-describedby="loginHelp">
        </div>

        <div class="mb-3">
            <label for="description" class="form-label">Цена</label>
            <input type="number" name="price" class="form-control" id="description" aria-describedby="loginHelp">
        </div>

        <button type="submit" class="btn btn-primary">Создать заявление</button>
    </form>
    <?php if($errors->any()): ?>

    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="alert alert-danger mt-1" role="alert">
        <?php echo e($error); ?>

    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\foodkor\resources\views/products/create.blade.php ENDPATH**/ ?>