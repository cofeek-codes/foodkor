<?php $__env->startSection('title'); ?>
Нарушений нет | Заявления
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php if(count($statements) == 0): ?>
<h1>Нет заявлений</h1>
<?php endif; ?>
<?php $__currentLoopData = $statements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $statement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


<div class="card mt-3">
    <div class="card-body">
        <h5 class="card-title"><?php echo e($statement->title); ?></h5>
        <p class="card-text text-truncate"><?php echo e($statement->description); ?></p>
        <a href="/statements/show/<?php echo e($statement->id); ?>" class="btn btn-primary">смотреть</a>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div class="mt-5 d-flex justify-content-center">
    <a href="/createStatement" class="btn btn-primary">Создать заявление</a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\practicekor\resources\views/statements/all.blade.php ENDPATH**/ ?>