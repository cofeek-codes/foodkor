<?php $__env->startSection('title'); ?>
Нарушений нет | Корзина
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<form action="/cart/order" method="POST">
    <?php echo csrf_field(); ?>
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


    <div class="card mt-3">
        <div class="card-body">
            <input name="name[]" value="<?php echo e($product->name); ?>" class="card-title">
            <input type="number" name="amount[]" value="0">
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <input type="text" name="address" class="form-control mt-5" placeholder="address">
    <div class="mt-5 d-flex justify-content-center">
        <button class="btn btn-primary" type="submit">Заказать</button>
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\foodkor\resources\views/cart/all.blade.php ENDPATH**/ ?>