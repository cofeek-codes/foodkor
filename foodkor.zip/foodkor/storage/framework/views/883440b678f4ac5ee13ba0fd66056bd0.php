

<?php $__env->startSection('title'); ?>
Нарушений нет | Заявления
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>



<div class="card">
    <?php if($product->image !== null): ?>
    <img src="<?php echo e($product->image); ?>" width="150" height="150" class="card-image">
    <?php endif; ?>
</div>
<div class="card-body">
    <h5 class="card-title"><?php echo e($product->title); ?></h5>
</div>
<div class="card-footer"><?php echo e($product->price); ?></div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\foodkor\resources\views/admin/show.blade.php ENDPATH**/ ?>