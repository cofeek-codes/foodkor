

<?php $__env->startSection('title'); ?>
Нарушений нет | Админ
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php if(count($products) == 0): ?>
<h1>Не найдено</h1>
<?php endif; ?>
<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<form action="/admin/search">
    <?php echo csrf_field(); ?>
    <input class="form-control" name="search">
    <button type="submit" class="btn btn-primary">Искать</button>
</form>


<div class="card mt-3">
    <div class="card-body">
        <h5 class="card-title"><?php echo e($product->name); ?></h5>
        <h3>Цена: <?php echo e($product->price); ?></h3>
        <?php if($product->image !== null): ?>
        <img src="<?php echo e($product->image); ?>" alt="<?php echo e($product->title); ?>">
        <?php endif; ?>
        <p class="card-text text-truncate"><?php echo e($product->description); ?></p>
        <a href="/admin/show/<?php echo e($product->id); ?>" class="btn btn-primary">смотреть</a>
        <a href="/admin/delete/<?php echo e($product->id); ?>" class="btn btn-danger">удалить</a>

    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div class="mt-5 d-flex justify-content-center align-items-center">
    <a href="/createproduct" class="btn btn-primary">Создать продукт</a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\foodkor\resources\views/admin/search.blade.php ENDPATH**/ ?>