<?php $__env->startSection('title'); ?>
Авоська | Заказы
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php if(count($orders) == 0): ?>
<h1>Нет заказов</h1>
<?php endif; ?>
<?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


<div class="card mt-3">
    <div class="card-body">
        <h5 class="card-title">Заказ №<?php echo e($order->id); ?></h5>
        <p class="card-text text-truncate"><?php echo e($order->address); ?></p>
        <a href="/orders/show/<?php echo e($order->id); ?>" class="btn btn-primary">смотреть</a>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\foodkor\resources\views/orders/all.blade.php ENDPATH**/ ?>