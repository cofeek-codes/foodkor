

<?php $__env->startSection('title'); ?>
Нарушениям нет
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="mx-auto my-auto">
    <div class="bg-primary d-flex align-items-center px-3 justify-content-between">
        <div>
            <img src="/img/logo.png" width="150" height="150" alt="big logo">
        </div>
        <div class="fs-1  text-white text-bold me-3">
            НАРУШЕНИЯМ.НЕТ
        </div>
    </div>
    <div class="mt-5 d-flex justify-content-center">
        <a href="/statements" class="btn btn-primary">Посмотреть заявления</a>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\practicekor\resources\views/home.blade.php ENDPATH**/ ?>