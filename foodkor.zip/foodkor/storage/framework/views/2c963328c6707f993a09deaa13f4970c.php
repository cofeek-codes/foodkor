

<?php $__env->startSection('title'); ?>
Нарушений нет | Авторизация
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="my-auto">
    <form action="/auth/login" method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="exampleInputLogin1" class="form-label">Login</label>
            <input type="text" name="login" class="form-control" id="exampleInputLogin1" aria-describedby="loginHelp">
            <div id="loginHelp" class="form-text">Ваши данные в безопасности</div>
        </div>
        <div class="mb-3">
            <label for="exampleInputPassword1" class="form-label">Пароль</label>
            <input type="password" name="password" class="form-control" id="exampleInputPassword1">
        </div>
        <button type="submit" class="btn btn-primary">Войти</button>
    </form>
    <?php if($errors->any()): ?>

    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="alert alert-danger mt-1" role="alert">
        <?php echo e($error); ?>

    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\foodkor\resources\views/auth/login.blade.php ENDPATH**/ ?>