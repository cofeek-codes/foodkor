@extends('base')

@section('title')
Нарушений нет | Авторизация
@endsection

@section('content')
<div class="my-auto">
    <form action="/auth/login" method="POST">
        @csrf
        <div class="mb-3">
            <label for="exampleInputLogin1" class="form-label">Login</label>
            <input type="text" name="login" class="form-control" id="exampleInputLogin1" aria-describedby="loginHelp">
            <div id="loginHelp" class="form-text">Ваши данные в безопасности</div>
        </div>
        <div class="mb-3">
            <label for="exampleInputPassword1" class="form-label">Пароль</label>
            <input type="password" name="password" class="form-control" id="exampleInputPassword1">
        </div>
        <button type="submit" class="btn btn-primary">Войти</button>
    </form>
    @if ($errors->any())

    @foreach ($errors->all() as $error)
    <div class="alert alert-danger mt-1" role="alert">
        {{ $error }}
    </div>
    @endforeach
    @endif
</div>
@endsection