@extends('base')

@section('title')
Нарушений нет | Авторизация
@endsection

@section('content')
<div class="my-auto">
    <form action="/auth/register" method="POST">
        @csrf
        <div class="mb-3">
            <label for="exampleInputName1" class="form-label">ФИО</label>
            <input type="text" name="name" class="form-control" id="exampleInputName1" aria-describedby="nameHelp">

        </div>
        <div class="mb-3">
            <label for="exampleInputPhone1" class="form-label">Номер телефона</label>
            <input type="text" name="phone" class="form-control" placeholder="+7(XXX)-XXX-XX-XX" id="exampleInputPhone1" aria-describedby="phoneHelp">

        </div>

        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Почта</label>
            <input type="email" name="email" class="form-control" placeholder="name@mail.ru" id="exampleInputEmail1" aria-describedby="emailHelp">

        </div>
        <div class="mb-3">
            <label for="exampleInputLogin1" class="form-label">Login</label>
            <input type="text" name="login" class="form-control" id="exampleInputLogin1" aria-describedby="loginHelp">
            <div id="loginHelp" class="form-text">Ваши данные в безопасности</div>
        </div>
        <div class="mb-3">
            <label for="exampleInputPassword1" class="form-label">Пароль</label>
            <input type="password" name="password" class="form-control" id="exampleInputPassword1">
        </div>
        <button type="submit" class="btn btn-primary">Зарегистрироваться</button>
    </form>
    @if ($errors->any())

    @foreach ($errors->all() as $error)
    <div class="alert alert-danger mt-1" role="alert">
        {{ $error }}
    </div>
    @endforeach
    @endif
</div>
@endsection