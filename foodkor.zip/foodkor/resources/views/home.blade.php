@extends('base')

@section('title')
Авоська
@endsection

@section('content')
<div class="mx-auto my-auto">
    <div class="bg-primary d-flex align-items-center px-3 justify-content-between">
        <div>
            <img src="/img/logo.png" width="150" height="150" alt="big logo">
        </div>
        <div class="fs-1  text-white text-bold me-3">
            Авоська
        </div>
    </div>

    <div class="mt-5 d-flex justify-content-center">
        @foreach ($products as $product)

        <div class="card" style="width: 18rem;">
            <img src="{{$product->image}}" width="300" height="300" class="card-img-top" alt="{{$product->name}}">
            <div class="card-body">
                <h5 class="card-title text-truncate">{{$product->name}}</h5>
                <p class="card-text">Цена: {{$product->price}} рублей</p>
                <a href="/cart" class="btn btn-primary">Заказать</a>
            </div>
        </div>
        @endforeach
    </div>

</div>
@endsection