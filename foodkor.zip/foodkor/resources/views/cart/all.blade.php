@extends('base')

@section('title')
Нарушений нет | Корзина
@endsection

@section('content')

<form action="/cart/order" method="POST">
    @csrf
    @foreach ($products as $product)


    <div class="card mt-3">
        <div class="card-body">
            <input name="name[]" value="{{$product->name}}" class="card-title">
            <input type="number" name="amount[]" value="0">
        </div>
    </div>
    @endforeach
    <input type="text" name="address" class="form-control mt-5" placeholder="address">
    <div class="mt-5 d-flex justify-content-center">
        <button class="btn btn-primary" type="submit">Заказать</button>
    </div>
</form>
@endsection