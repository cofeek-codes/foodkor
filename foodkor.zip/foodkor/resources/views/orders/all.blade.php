@extends('base')

@section('title')
Авоська | Заказы
@endsection

@section('content')
@if (count($orders) == 0)
<h1>Нет заказов</h1>
@endif
@foreach ($orders as $order)


<div class="card mt-3">
    <div class="card-body">
        <h5 class="card-title">Заказ №{{$order->id}}</h5>
        <p class="card-text text-truncate">{{$order->address}}</p>
        <a href="/orders/show/{{$order->id}}" class="btn btn-primary">смотреть</a>
    </div>
</div>
@endforeach
@endsection