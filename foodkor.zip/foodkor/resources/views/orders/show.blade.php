@extends('base')

@section('title')
Нарушений нет | Заявления
@endsection

@section('content')



<div class="card">
    <div class="card-body">
        <h5 class="card-title">Заказ №{{$order->id}}</h5>
        <p class="card-text text-truncate">{{$order->address}}</p>
        <p>Статус: {{$order->status}}</p>
        <p>
            {{json_decode($order->products)}}
        </p>
    </div>

</div>
@endsection