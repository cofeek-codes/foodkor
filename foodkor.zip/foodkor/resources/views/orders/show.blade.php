@extends('base')

@section('title')
Нарушений нет | Заявления
@endsection

@section('content')



<div class="card">
    <div class="card-body">
        <h5 class="card-title">Заказ №{{$order->id}}</h5>
        <p class="card-text text-truncate">{{$order->address}}</p>
        <p>Статус: {{$order->status}}</p>
        <h3>Корзина</h3>
        <p>

            @foreach ($productsCounts as $productCount)
            @foreach ($productsNames as $productName)
            {{$productName}}:{{$productCount}} <br>
            @endforeach
            @endforeach
        </p>
    </div>

</div>
@endsection