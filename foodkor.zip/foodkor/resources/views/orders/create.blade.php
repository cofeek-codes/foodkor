@extends('base')

@section('title')
Нарушений нет | Создать заявление
@endsection

@section('content')
<div class="my-auto">
    <form action="/statements/create" method="POST">
        @csrf
        <div class="mb-3">
            <label for="title" class="form-label">Название</label>
            <input type="text" name="title" class="form-control" id="title" aria-describedby="loginHelp">
        </div>

        <div class="mb-3">
            <label for="description" class="form-label">Описание</label>
            <input type="text" name="description" class="form-control" id="description" aria-describedby="loginHelp">
        </div>

        <div class="mb-3">
            <label for="carNumber" class="form-label">Номер автомобиля</label>
            <input type="text" name="carNumber" class="form-control" id="carNumber" aria-describedby="loginHelp">
        </div>
        <button type="submit" class="btn btn-primary">Создать заявление</button>
    </form>
    @if ($errors->any())

    @foreach ($errors->all() as $error)
    <div class="alert alert-danger mt-1" role="alert">
        {{ $error }}
    </div>
    @endforeach
    @endif
</div>
@endsection