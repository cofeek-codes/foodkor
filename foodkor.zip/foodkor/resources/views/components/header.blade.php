<nav class="navbar navbar-expand-lg bg-body-tertiary">
    <div class="container-fluid">
        <img src="/img/logo.png" class="mx-2" width="30" hegiht="30" alt="logo">
        <a class="navbar-brand" href="#">Авоська</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="/">Главная</a>
                </li>
                @auth
                <li class="nav-item">
                    <a class="nav-link" href="/orders/all">Заказы</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/admin">Админ</a>
                </li>
                @endauth
            </ul>
            @auth
            <div class="flex">
                <a href="/auth/logout" class="btn btn-primary me-1">Выйти</a>
            </div>
            @else
            <div class="flex">
                <a href="/auth/login" class="btn btn-primary me-1">Войти</a><a href="/auth/register" class="btn btn-outline-primary">Регистрация</a>
            </div>
            @endauth
        </div>
    </div>
</nav>