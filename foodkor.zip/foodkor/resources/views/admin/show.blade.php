@extends('base')

@section('title')
Нарушений нет | Заявления
@endsection

@section('content')



<div class="card">
    @if ($product->image !== null)
    <img src="{{$product->image}}" width="150" height="150" class="card-image">
    @endif
</div>
<div class="card-body">
    <h5 class="card-title">{{$product->title}}</h5>
</div>
<div class="card-footer">{{$product->price}}</div>
</div>
@endsection