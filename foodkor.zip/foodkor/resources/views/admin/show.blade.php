@extends('base')

@section('title')
Нарушений нет | Заявления
@endsection

@section('content')



<div class="card">
    <div class="card-body">
        <h5 class="card-title">{{$statement->title}}</h5>
        <p class="card-text text-truncate">{{$statement->description}}</p>
        <p>Статус: {{$statement->status}}</p>
    </div>
    <div class="card-footer">{{$statement->carNumber}}</div>
</div>
@endsection