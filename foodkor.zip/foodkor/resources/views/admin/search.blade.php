@extends('base')

@section('title')
Нарушений нет | Админ
@endsection

@section('content')
@if (count($products) == 0)
<h1>Не найдено</h1>
@endif
@foreach ($products as $product)

<form action="/admin/search">
    @csrf
    <input class="form-control" name="search">
    <button type="submit" class="btn btn-primary">Искать</button>
</form>


<div class="card mt-3">
    <div class="card-body">
        <h5 class="card-title">{{$product->name}}</h5>
        <h3>Цена: {{$product->price}}</h3>
        @if ($product->image !== null)
        <img src="{{$product->image}}" alt="{{$product->title}}">
        @endif
        <p class="card-text text-truncate">{{$product->description}}</p>
        <a href="/admin/show/{{$product->id}}" class="btn btn-primary">смотреть</a>
        <a href="/admin/delete/{{$product->id}}" class="btn btn-danger">удалить</a>

    </div>
</div>
@endforeach
<div class="mt-5 d-flex justify-content-center align-items-center">
    <a href="/createproduct" class="btn btn-primary">Создать продукт</a>
</div>
@endsection