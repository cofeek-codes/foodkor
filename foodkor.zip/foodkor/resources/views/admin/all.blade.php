@extends('base')

@section('title')
Нарушений нет | Админ
@endsection

@section('content')
@if (count($statements) == 0)
<h1>Нет заявлений</h1>
@endif
@foreach ($statements as $statement)


<div class="card mt-3">
    <div class="card-body">
        <h5 class="card-title">{{$statement->title}}</h5>
        <p class="card-text text-truncate">{{$statement->description}}</p>
        <a href="/admin/show/{{$statement->id}}" class="btn btn-primary">смотреть</a>
        <a href="/admin/approve/{{$statement->id}}" class="btn btn-success">подтвердить</a>
        <a href="/admin/delete/{{$statement->id}}" class="btn btn-danger">отклонить</a>

    </div>
</div>
@endforeach
@endsection