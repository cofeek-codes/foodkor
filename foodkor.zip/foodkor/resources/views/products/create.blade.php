@extends('base')

@section('title')
Нарушений нет | Создать продукт
@endsection

@section('content')
<div class="my-auto">
    <form action="/products/create" method="POST">
        @csrf
        <div class="mb-3">
            <label for="title" class="form-label">Название</label>
            <input type="text" name="name" class="form-control" id="title" aria-describedby="loginHelp">
        </div>

        <div class="mb-3">
            <label for="description" class="form-label">Цена</label>
            <input type="number" name="price" class="form-control" id="description" aria-describedby="loginHelp">
        </div>

        <button type="submit" class="btn btn-primary">Создать заявление</button>
    </form>
    @if ($errors->any())

    @foreach ($errors->all() as $error)
    <div class="alert alert-danger mt-1" role="alert">
        {{ $error }}
    </div>
    @endforeach
    @endif
</div>
@endsection