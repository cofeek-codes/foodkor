<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        for ($i = 0; $i < 3; $i++) {
            DB::table('products')->insert([
                'name' => fake()->words(rand(1, 5), true),
                'price' => rand(100, 999),
                'image' => '/img/' . rand(1, 6) . '.jpg',
            ]);
        }
    }
}
