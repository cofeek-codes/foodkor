<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        for ($i = 0; $i < 3; $i++) {
            DB::table('users')->insert([
                'name' => "" . fake()->name('male') . fake()->lastName('male') . fake()->lastName('male') . "",
                'email' => fake()->email(),
                'phone' => "+7(" . rand(1, 9) . rand(1, 9) . rand(1, 9) . ")-" . rand(1, 9) . rand(1, 9) . rand(1, 9) . "-" . rand(1, 9) . rand(1, 9) . '-' . rand(1, 9) . rand(1, 9),
                'login' => 'test' . rand(1, 9),
                'password' => Hash::make('test123'),
                'isAdmin' => fake()->boolean(),

            ]);
        }
    }
}
