<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\CartController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\ProductController;
use App\Models\Order;
use App\Models\Product;
use App\Models\Statement;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('home', ['products' => Product::take(3)->get()]);
});

// auth

Route::controller(AuthController::class)->group(function () {
    Route::get('/auth/login', 'login');
    Route::get('/auth/logout', 'logout');
    Route::post('/auth/login', 'login');
    Route::get('/auth/register', 'register');
    Route::post('/auth/register', 'register');
});

// orders
Route::controller(OrderController::class)->group(function () {
    Route::get('/orders/all', 'getAll');
    Route::get('/orders/show/{order_id}', 'show');
});

// products

Route::controller(ProductController::class)->group(function () {
    Route::get('/products/all', 'getAll');
});

// cart
Route::get('/cart/{product_id}', function ($product_id) {
    Cache::add($product_id, 1);
});


Route::controller(CartController::class)->group(function () {
    Route::get('/cart/', 'getAll');
});

Route::controller(CartController::class)->group(function () {
    Route::post('/cart/order', 'order');
});


// admin

Route::controller(AdminController::class)->group(function () {
    Route::get('/admin', 'redirect');
    Route::get('/admin/all', 'getAll');
    Route::get('/admin/show/{statement_id}', 'show');
    Route::get('/admin/approve/{statement_id}', 'approve');
    Route::get('/admin/delete/{statement_id}', 'delete');
});
Route::get('/createStatement', function () {
    return view('statements.create');
});
