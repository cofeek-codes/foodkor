<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Http\Request;

class AdminController extends Controller
{
    public function redirect()
    {
        return redirect('/admin/all');
    }
    public function getAll()
    {
        $products = Product::all();

        return view('admin.all', ['products' => $products]);
    }

    public function search(Request $request)
    {
        $results = Product::where('name', 'LIKE', '%' . $request->input('search') . '%')->get();
        return view('admin.search', ['products' => $results]);
    }

    public function show($product_id)
    {
        $product = Product::find($product_id);

        return view('admin.show', ['product' => $product]);
    }


    public function delete($product_id)
    {
        $product = Product::find($product_id);
        $product->delete();
        return back();
    }
}
