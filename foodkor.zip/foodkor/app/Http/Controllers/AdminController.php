<?php

namespace App\Http\Controllers;

use App\Models\Statement;
use Illuminate\Http\Request;

class AdminController extends Controller
{
    public function redirect()
    {
        return redirect('/admin/all');
    }
    public function getAll()
    {
        $statements = Statement::all();

        return view('admin.all', ['statements' => $statements]);
    }
    public function show($statement_id)
    {
        $statement = Statement::find($statement_id);

        return view('admin.show', ['statement' => $statement]);
    }

    public function approve($statement_id)
    {
        $statement = Statement::find($statement_id);
        $statement->update(['status' => 'approved']);
        return view('admin.show', ['statement' => $statement]);
    }
    public function delete($statement_id)
    {
        $statement = Statement::find($statement_id);
        $statement->update(['status' => 'canceled']);
        return view('admin.show', ['statement' => $statement]);
    }
}
