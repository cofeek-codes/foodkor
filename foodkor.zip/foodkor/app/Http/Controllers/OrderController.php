<?php

namespace App\Http\Controllers;

use App\Models\Order;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class OrderController extends Controller
{
    public function getAll()
    {
        return view('orders.all', ['orders' => Order::where('user_id', Auth::id())->get()]);
    }

    public function show($order_id)
    {
        $order = Order::find($order_id);
        $productsCounts = json_decode($order->products, true);
        $productsNames = array_keys($productsCounts);
        return view('orders.show', ['order' => $order, 'productsCounts' => $productsCounts, 'productsNames' => $productsNames]);
    }
}
