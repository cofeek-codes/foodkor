<?php

namespace App\Http\Controllers;

use App\Models\Order;
use Illuminate\Http\Request;

class OrderController extends Controller
{
    public function getAll()
    {
        return view('orders.all', ['orders' => Order::all()]);
    }

    public function show($order_id)
    {
        $order = Order::find($order_id);
        dd(json_decode($order->products)->toArray());
        return view('orders.show', ['order' => $order]);
    }
}
