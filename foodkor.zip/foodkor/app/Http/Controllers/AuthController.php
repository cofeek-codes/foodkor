<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{
    public function login(Request $request)
    {
        if ($request->method() == "GET") {

            return view('auth.login');
        }
        if ($request->method() == "POST") {
            $credentials = $request->validate([
                'login' => ['required', 'min:3'],
                'password' => ['required', 'min:6'],
            ]);

            if (Auth::attempt($credentials)) {
                $request->session()->regenerate();

                return redirect('/');
            }
            return back()->withErrors(['login' => 'incrorrect login', 'password' => 'incrorrect password']);
        }
    }
    public function register(Request $request)
    {
        if ($request->method() == "GET") {
            return view('auth.register');
        }
        if ($request->method() == 'POST')
            $validated = $request->validate([
                'name' => 'required',
                'email' => 'required|email',
                'login' => 'required',
                'phone' => 'required',
                'password' => 'required|min:3',

            ]);

        $newUser = User::create($validated);
        Auth::loginUsingId($newUser->id);
        return redirect('/');
    }
    public function logout()
    {
        Auth::logout();
        return redirect('/');
    }
}
