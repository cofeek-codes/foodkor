<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CartController extends Controller
{
    public function getAll()
    {
        // dd(Product::all());
        return view('cart.all', ['products' => Product::all()]);
    }

    public function order(Request $request)
    {
        if (!Auth::check())
            return redirect('/auth/login');

        $products = [];
        for ($i = 0; $i < count($request->input('name')); $i++) {
            $products += [
                $request->input('name')[$i] => $request->input('amount')[$i],
            ];
        }

        Order::create([
            'address' => $request->input('address'),
            'status' => 'new',
            'user_id' => Auth::id(),
            'products' => json_encode($products),
        ]);

        return redirect('/');
    }
}
